var sample = "code"
